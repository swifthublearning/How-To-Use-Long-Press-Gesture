//
//  ViewController.swift
//  how to use long press gesture
//
//  Created by Supine Hub Technologies Pvt. Ltd. on 10/03/20.
//  Copyright © 2020 Supine Hub Technologies Pvt. Ltd. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let longpressgesture = UILongPressGestureRecognizer()
        self.view.addGestureRecognizer(longpressgesture)
        longpressgesture.addTarget(self, action: #selector(clicklongpress))
    }
    
    @objc func clicklongpress()
    {
        print("Long Press Click Successfully")
    }

    @IBAction func withoutprogramminggesture(_ sender: Any) {
        print("Image Long Press Gesture Click Successfully")
    }
    
}

